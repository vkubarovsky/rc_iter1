"""Load the four asymmetry data sets and turn a model into the measured quantity.

Self-contained: needs only numpy, and a function that returns the structure
functions of your model at (Q2, xB, t).  Nothing here converts the data -- every
set is kept as published and the model is converted instead.

    import load_asymmetries as A
    sets = A.load()                       # dict of name -> list of rows
    A.predict(row, sf)                    # what your model should give for that row

`sf` is whatever your code returns for one kinematic point; it must support
    sf["T"], sf["L"], sf["LT"], sf["TT"], sf["LTp"]
and, only for eg1,
    sf["LTUL"], sf["TTUL"], sf["Tp"], sf["LTpLL"]
all in the same units and the same convention as CLAS6: the phi decomposition

    d2sigma/dt dphi = 1/(2 pi) [ sigma_T + eps sigma_L
                                 + eps cos(2 phi) sigma_TT
                                 + sqrt(2 eps (1+eps)) cos(phi) sigma_LT
                                 + h sqrt(2 eps (1-eps)) sin(phi) sigma_LT' ]
"""
import json, math, os, pickle
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MP = 0.9382720813
E_CLAS6, E_CLAS12, E_EG1 = 5.776, 10.6, 5.9

def epsilon(xB, Q2, E):
    y = Q2/(2*MP*xB*E); g2 = 4*MP*MP*xB*xB/Q2
    return (1 - y - 0.25*g2*y*y)/(1 - y + y*y/2 + 0.25*g2*y*y)

def load():
    d = {}
    # 1. De Masi, phi level
    rows = []
    for name, arr in pickle.load(open(f"{HERE}/data/demasi_phi.pkl", "rb")):
        for r in arr:
            if r[5] <= 0: continue
            rows.append(dict(kind="A_phi", ch="pi0p", bin=name,
                             Q2=float(r[1]), xB=float(r[0]), mt=float(r[2]),
                             phi=math.radians(float(r[3])),
                             value=float(r[4]), err=float(r[5]),
                             eps=epsilon(float(r[0]), float(r[1]), E_CLAS6)))
    d["demasi_phi"] = rows
    # 2. Zhao, sin-phi amplitude
    rows = []
    for v in np.loadtxt(f"{HERE}/data/zhao_vector.data"):
        rows.append(dict(kind="alpha", ch="etap", Q2=v[0], xB=v[1], mt=v[2],
                         value=v[3], err=math.hypot(v[4], v[5]),
                         eps=epsilon(v[1], v[0], E_CLAS6)))
    d["zhao"] = rows
    # 3. Kim CLAS12, the ratio itself
    rows = []
    for v in np.loadtxt(f"{HERE}/data/clas12_kim_sigLTp.data"):
        rows.append(dict(kind="ratio", ch="pi0p", Q2=v[0], xB=v[1], mt=v[2],
                         value=v[3], err=math.hypot(v[4], v[5]),
                         eps=epsilon(v[1], v[0], E_CLAS12)))
    d["clas12"] = rows
    # 4. eg1-dvcs
    EG = json.load(open(f"{HERE}/data/eg1dvcs_pi0_target_asym.json"))
    KIN = {"1.94": 0.25, "2.83": 0.40}
    REC = {"E154M5": "AULsin", "E154M6": "AULsin", "E154M7": "AULsin2",
           "E154M8": "AULsin2", "E154M9": "ALLc", "E154M10": "ALLc",
           "E154M11": "ALLcos", "E154M12": "ALLcos"}
    rows = []
    for rec, key in REC.items():
        for r in EG[rec]["rows"]:
            Q2, mt, A, dA = r[0], r[1], r[2], r[3]
            ds = r[4] if len(r) > 4 else 0.0
            xB = KIN[f"{Q2:.2f}"]
            rows.append(dict(kind=key, ch="pi0p", Q2=Q2, xB=xB, mt=mt,
                             value=A, err=math.hypot(dA, ds),
                             eps=epsilon(xB, Q2, E_EG1)))
    d["eg1"] = rows
    return d

def predict(row, sf):
    """The model value for one row.  sf is your structure functions at that point."""
    e = row["eps"]; s0 = sf["T"] + e*sf["L"]
    k = row["kind"]
    if k == "ratio":                       # CLAS12 publishes the ratio itself
        return sf["LTp"]/s0
    if k == "alpha":                       # Zhao publishes the sin-phi amplitude
        return math.sqrt(2*e*(1-e))*sf["LTp"]/s0
    if k == "A_phi":                       # De Masi: the full phi dependence
        p = row["phi"]
        den = (1 + math.sqrt(2*e*(1+e))*sf["LT"]/s0*math.cos(p)
                 + e*sf["TT"]/s0*math.cos(2*p))
        return math.sqrt(2*e*(1-e))*sf["LTp"]/s0*math.sin(p)/den
    if k == "AULsin":  return math.sqrt(2*e*(1+e))*sf["LTUL"]/s0
    if k == "AULsin2": return e*sf["TTUL"]/s0
    if k == "ALLc":    return math.sqrt(1-e*e)*sf["Tp"]/s0
    if k == "ALLcos":  return math.sqrt(2*e*(1-e))*sf["LTpLL"]/s0
    raise ValueError(k)

if __name__ == "__main__":
    d = load()
    print(f"{'set':>12}{'points':>8}   kinds")
    for k, v in d.items():
        print(f"{k:>12}{len(v):8d}   {sorted({r['kind'] for r in v})}")
    print(f"{'':>12}{sum(len(v) for v in d.values()):8d}   total")
